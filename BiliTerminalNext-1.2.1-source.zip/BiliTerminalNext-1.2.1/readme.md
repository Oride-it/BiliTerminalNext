# 哔哩终端Next

轻量的第三方哔哩哔哩 Android 客户端，由 Oride-it 维护。

[下载正式版](https://github.com/Oride-it/BiliTerminalNext/releases/latest) · [更新记录](CHANGELOG.md) · [构建说明](NEXT_BUILD.md)

本仓库的首个正式版本为 **1.2.1**，后续依次发布 **1.2.2、1.2.3……**。

## 界面与功能

- 暗酒红到纯黑的页面渐变，炭灰圆形菜单、圆外文字和粉色未读角标。
- 单列、双列、三列菜单；长按拖动卡片，支持返回自动保存与手动保存。
- 每行四个圆形预设色块，支持编辑十六进制色号，预览后保存。
- 账号管理显示头像、昵称和 UID，支持添加账号与切换登录会话。
- 保留上游的视频、搜索、动态、收藏、缓存与内置播放器等功能。

| 菜单 | 个性主题 |
| --- | --- |
| <img src="docs/images/menu-preview.png" width="250" alt="菜单界面渲染预览"> | <img src="docs/images/theme-preview.png" width="250" alt="个性主题界面渲染预览"> |

预览图来自 Android 原生图形渲染测试；图中的时间和未读数为演示数据。

## 安装

在 [Releases](https://github.com/Oride-it/BiliTerminalNext/releases) 下载最新 APK。

- 应用名称：哔哩终端Next
- 安装包名：`com.iftts.bili`
- 最低 Android 版本：4.0（API 14）
- 原生库架构：`armeabi-v7a`、`x86`、`mips`；不支持纯 64 位设备。
- 后续版本沿用同一发布密钥，可覆盖更新本分支此前的安装包。
- 本分支与原版使用不同包名，初次安装需要重新登录。

## 版本与构建

版本统一由 [version.properties](version.properties) 管理。发布下一个补丁版本：

```sh
python3 scripts/bump_version.py --dry-run
python3 scripts/bump_version.py
```

脚本会同时增加补丁版本号和 Android 内部安装序号，以保持覆盖更新兼容性。
正式包开启 R8 代码混淆、优化和资源压缩，构建步骤见 [NEXT_BUILD.md](NEXT_BUILD.md)。

## 反馈

请在 [Issues](https://github.com/Oride-it/BiliTerminalNext/issues) 附上应用版本、设备型号、Android 版本和复现步骤。
请勿上传登录 Cookie、令牌或其他账号私密信息。

## 开源与致谢

本分支基于 [PianoEthan/BiliTerminal](https://github.com/PianoEthan/BiliTerminal)，基础提交为 `c2d4f24079fd7903f50bdc67d2d8c98f0614cca2`。
感谢原作者 RobinNotBad 及上游项目的贡献者。原项目说明保留于 [UPSTREAM_README.md](docs/UPSTREAM_README.md)。

本项目沿用 [GNU GPL v3](LICENSE) 许可证。随附第三方组件保留各自许可证与署名。
