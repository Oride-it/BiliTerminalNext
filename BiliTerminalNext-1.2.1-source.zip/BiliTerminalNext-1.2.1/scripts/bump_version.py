#!/usr/bin/env python3
"""Advance the patch version and Android installation code together."""
import argparse
from pathlib import Path
import re

parser = argparse.ArgumentParser(description="Advance 1.2.1 -> 1.2.2 and increase VERSION_CODE")
parser.add_argument("--dry-run", action="store_true", help="Show the next version without changing files")
args = parser.parse_args()
path = Path(__file__).resolve().parents[1] / "version.properties"
values = dict(line.split("=", 1) for line in path.read_text().splitlines() if line and not line.startswith("#"))
match = re.fullmatch(r"(\d+)\.(\d+)\.(\d+)", values["VERSION_NAME"])
if match is None:
    parser.error("VERSION_NAME must be a three-part version such as 1.2.1")
major, minor, patch = map(int, match.groups())
next_name = f"{major}.{minor}.{patch + 1}"
next_code = int(values["VERSION_CODE"]) + 1
if not args.dry_run:
    path.write_text(f"VERSION_NAME={next_name}\nVERSION_CODE={next_code}\n")
print(f"{values['VERSION_NAME']} -> {next_name} (VERSION_CODE {next_code})")
