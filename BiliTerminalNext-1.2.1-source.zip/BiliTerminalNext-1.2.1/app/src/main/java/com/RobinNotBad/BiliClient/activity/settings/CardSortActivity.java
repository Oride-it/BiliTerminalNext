package com.RobinNotBad.BiliClient.activity.settings;

import android.os.Bundle;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.ItemTouchHelper;
import com.RobinNotBad.BiliClient.R;
import com.RobinNotBad.BiliClient.activity.base.BaseActivity;
import com.RobinNotBad.BiliClient.adapter.MenuPlacementAdapter;
import com.RobinNotBad.BiliClient.util.MenuOrder;
import com.RobinNotBad.BiliClient.util.NextLayout;
import com.RobinNotBad.BiliClient.util.MsgUtil;
import java.util.ArrayList;
import java.util.List;

public class CardSortActivity extends BaseActivity {
    private final List<String> keys = new ArrayList<>();
    @Override protected void onCreate(Bundle state) {
        super.onCreate(state); setContentView(R.layout.activity_next_settings); setPageName("更换模式 · 长按拖动");
        ArrayList<String> restored = state == null ? null : state.getStringArrayList("card_order");
        keys.addAll(restored == null ? MenuOrder.visible() : restored);
        LinearLayout root = (LinearLayout) findViewById(R.id.top).getParent(); root.removeViewAt(1);
        RecyclerView grid = new RecyclerView(this); grid.setId(R.id.next_card_preview);
        grid.setLayoutManager(new GridLayoutManager(this, NextLayout.columns()));
        grid.setClipToPadding(false); grid.setPadding(8, 8, 8, 8);
        root.addView(grid, new LinearLayout.LayoutParams(-1, 0, 1));
        MenuPlacementAdapter adapter = new MenuPlacementAdapter(keys);
        ItemTouchHelper helper = new ItemTouchHelper(new ItemTouchHelper.Callback() {
            @Override public int getMovementFlags(@NonNull RecyclerView view, @NonNull RecyclerView.ViewHolder holder) {
                int directions = ItemTouchHelper.UP | ItemTouchHelper.DOWN;
                if (NextLayout.columns() > 1) directions |= ItemTouchHelper.LEFT | ItemTouchHelper.RIGHT;
                return makeMovementFlags(directions, 0);
            }
            @Override public boolean onMove(@NonNull RecyclerView view, @NonNull RecyclerView.ViewHolder from, @NonNull RecyclerView.ViewHolder to) {
                return moveCard(from.getAdapterPosition(), to.getAdapterPosition(), adapter);
            }
            @Override public void onSwiped(@NonNull RecyclerView.ViewHolder holder, int direction) { }
            @Override public boolean isLongPressDragEnabled() { return false; }
            @Override public boolean isItemViewSwipeEnabled() { return false; }
            @Override public void onSelectedChanged(@Nullable RecyclerView.ViewHolder holder, int state) {
                super.onSelectedChanged(holder, state);
                if (holder != null && state == ItemTouchHelper.ACTION_STATE_DRAG) {
                    holder.itemView.setScaleX(1.04f); holder.itemView.setScaleY(1.04f); holder.itemView.setAlpha(.8f);
                }
            }
            @Override public void clearView(@NonNull RecyclerView view, @NonNull RecyclerView.ViewHolder holder) {
                super.clearView(view, holder); holder.itemView.setScaleX(1); holder.itemView.setScaleY(1); holder.itemView.setAlpha(1);
                saveOrder();
            }
        });
        adapter.setDragListener(helper::startDrag); grid.setAdapter(adapter); helper.attachToRecyclerView(grid);
        com.google.android.material.button.MaterialButton save = new com.google.android.material.button.MaterialButton(this);
        save.setId(R.id.next_card_save); save.setText("保存");
        save.setOnClickListener(v -> { saveOrder(); MsgUtil.showMsg("卡片位置已保存"); finish(); });
        root.addView(save, new LinearLayout.LayoutParams(-1, -2));
        com.RobinNotBad.BiliClient.theme.ThemeApplier.applyContent(root);
    }
    public boolean moveCard(int from, int to, RecyclerView.Adapter<?> adapter) {
        if (from < 0 || to < 0 || from >= keys.size() || to >= keys.size() || from == to) return false;
        String moved = keys.remove(from); keys.add(to, moved); adapter.notifyItemMoved(from, to); return true;
    }
    private void saveOrder() { if (!keys.isEmpty()) MenuOrder.saveVisible(keys); }
    @Override protected void onPause() { saveOrder(); super.onPause(); }
    @Override protected void onSaveInstanceState(@NonNull Bundle state) {
        state.putStringArrayList("card_order", new ArrayList<>(keys)); saveOrder(); super.onSaveInstanceState(state);
    }
}
