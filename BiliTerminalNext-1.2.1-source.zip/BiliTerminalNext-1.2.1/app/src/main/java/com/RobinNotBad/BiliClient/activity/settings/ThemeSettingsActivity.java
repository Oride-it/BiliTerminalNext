package com.RobinNotBad.BiliClient.activity.settings;

import android.content.Intent;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.RobinNotBad.BiliClient.R;
import com.RobinNotBad.BiliClient.activity.base.BaseActivity;
import com.RobinNotBad.BiliClient.theme.ThemeApplier;
import com.google.android.material.card.MaterialCardView;

public class ThemeSettingsActivity extends BaseActivity {
    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(R.layout.activity_next_settings);
        setPageName("个性主题");
        LinearLayout content = findViewById(R.id.nextSettingsContent);
        String[] titles = {"页面设置", "颜色设置", "卡片位置设置"};
        int[] ids = {R.id.next_personal_page, R.id.next_personal_color, R.id.next_personal_cards};
        Class<?>[] pages = {LayoutSettingsActivity.class, BackgroundColorActivity.class, CardPositionActivity.class};
        int padding = (int)(10 * getResources().getDisplayMetrics().density);
        for (int i = 0; i < titles.length; i++) {
            final Class<?> page = pages[i];
            MaterialCardView card = new MaterialCardView(this); card.setId(ids[i]);
            card.setUseCompatPadding(false); card.setPreventCornerOverlap(false);
            TextView label = new TextView(this); label.setText(titles[i]);
            label.setMinHeight((int)(36*getResources().getDisplayMetrics().density)); label.setGravity(android.view.Gravity.CENTER_VERTICAL);
            label.setPadding(padding, (int)(7*getResources().getDisplayMetrics().density), padding, (int)(7*getResources().getDisplayMetrics().density)); label.setTextSize(13);
            android.graphics.drawable.Drawable arrow = androidx.appcompat.content.res.AppCompatResources.getDrawable(this, R.drawable.arrow_forward);
            if (arrow != null) {
                int size = (int)(14*getResources().getDisplayMetrics().density);
                arrow.setBounds(0, 0, size, size);
                androidx.core.widget.TextViewCompat.setCompoundDrawablesRelative(label, null, null, arrow, null);
            }
            card.addView(label); card.setOnClickListener(v -> startActivity(new Intent(this, page)));
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, -2); params.bottomMargin = (int)(3*getResources().getDisplayMetrics().density);
            content.addView(card, params);
        }
        ThemeApplier.applyContent(content);
    }
}
