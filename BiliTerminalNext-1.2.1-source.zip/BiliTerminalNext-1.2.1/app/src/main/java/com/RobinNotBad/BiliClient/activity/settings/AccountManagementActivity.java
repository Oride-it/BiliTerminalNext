package com.RobinNotBad.BiliClient.activity.settings;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.widget.LinearLayout;

import com.RobinNotBad.BiliClient.R;
import com.RobinNotBad.BiliClient.activity.base.BaseActivity;
import com.RobinNotBad.BiliClient.activity.settings.login.LoginActivity;
import com.RobinNotBad.BiliClient.activity.settings.login.SpecialLoginActivity;
import com.RobinNotBad.BiliClient.theme.ThemeApplier;
import com.RobinNotBad.BiliClient.util.AccountStore;
import com.RobinNotBad.BiliClient.util.SharedPreferencesUtil;
import com.google.android.material.button.MaterialButton;

import org.json.JSONArray;
import org.json.JSONObject;

public class AccountManagementActivity extends BaseActivity {
    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(R.layout.activity_next_settings);
        setPageName("账号管理");
        findViewById(R.id.pageName).setOnClickListener(v -> finish());
    }

    @Override
    protected void onResume() {
        super.onResume();
        AccountStore.saveCurrent();
        LinearLayout content = findViewById(R.id.nextSettingsContent);
        content.removeAllViews();
        JSONArray accounts = AccountStore.list();
        long current = SharedPreferencesUtil.getLong("mid", 0);
        if (accounts.length() == 0) {
            android.widget.TextView empty = new android.widget.TextView(this);
            empty.setText("尚未登录账号");
            empty.setPadding(8, 20, 8, 20);
            content.addView(empty);
        }
        for (int i = 0; i < accounts.length(); i++) {
            JSONObject account = accounts.optJSONObject(i);
            if (account == null) continue;
            long mid = account.optLong("mid");
            String name = account.optString("name", "");
            float density = getResources().getDisplayMetrics().density;
            com.google.android.material.card.MaterialCardView card = new com.google.android.material.card.MaterialCardView(this);
            LinearLayout row = new LinearLayout(this);
            row.setGravity(android.view.Gravity.CENTER_VERTICAL);
            int padding = (int) (12 * density);
            row.setPadding(padding, padding, padding, padding);
            android.widget.ImageView avatar = new android.widget.ImageView(this);
            row.addView(avatar, new LinearLayout.LayoutParams((int)(44*density), (int)(44*density)));
            com.bumptech.glide.Glide.with(this).load(account.optString("avatar", ""))
                    .placeholder(R.mipmap.akari).error(R.mipmap.akari).circleCrop().into(avatar);
            LinearLayout details = new LinearLayout(this);
            details.setOrientation(LinearLayout.VERTICAL);
            details.setPadding(padding, 0, 0, 0);
            android.widget.TextView title = new android.widget.TextView(this);
            title.setText((name.isEmpty() ? "第" + (i + 1) + "个账号" : name) + (mid == current ? " · 当前" : ""));
            title.setTextSize(13);
            title.setTypeface(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD);
            details.addView(title);
            android.widget.TextView uid = new android.widget.TextView(this);
            uid.setText("UID " + mid); uid.setTextSize(11);
            uid.setTextColor(com.RobinNotBad.BiliClient.theme.ThemeManager.palette().textSecondary);
            details.addView(uid);
            row.addView(details, new LinearLayout.LayoutParams(0, -2, 1));
            card.addView(row);
            card.setOnClickListener(v -> {
                if (AccountStore.select(mid)) AccountStore.openMySpace(this);
            });
            LinearLayout.LayoutParams cardParams = new LinearLayout.LayoutParams(-1, -2);
            cardParams.bottomMargin = (int)(8*density);
            content.addView(card, cardParams);
            if (account.optString("avatar", "").isEmpty()) {
                com.RobinNotBad.BiliClient.util.CenterThreadPool.run(() -> {
                    try {
                        JSONObject profile = com.RobinNotBad.BiliClient.util.NetWorkUtil
                                .getJson("https://api.bilibili.com/x/web-interface/card?mid=" + mid)
                                .getJSONObject("data").getJSONObject("card");
                        String profileName = profile.optString("name", name);
                        String face = profile.optString("face", "");
                        AccountStore.updateProfile(mid, profileName, face);
                        runOnUiThread(() -> {
                            if (isDestroyed()) return;
                            title.setText(profileName + (mid == current ? " · 当前" : ""));
                            com.bumptech.glide.Glide.with(this).load(face).placeholder(R.mipmap.akari)
                                    .error(R.mipmap.akari).circleCrop().into(avatar);
                        });
                    } catch (Exception ignored) { }
                });
            }
        }
        MaterialButton add = new MaterialButton(this);
        add.setText("＋ 添加新账号");
        add.setOnClickListener(v -> {
            AccountStore.saveCurrent();
            Intent login = new Intent(this, Build.VERSION.SDK_INT >= 19
                    ? LoginActivity.class : SpecialLoginActivity.class);
            login.putExtra("add_account", true);
            login.putExtra("login", true);
            startActivity(login);
        });
        content.addView(add);
        ThemeApplier.applyContent(content);
    }
}
