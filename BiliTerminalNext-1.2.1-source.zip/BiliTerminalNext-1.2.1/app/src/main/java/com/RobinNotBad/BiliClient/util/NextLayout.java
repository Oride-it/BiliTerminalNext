package com.RobinNotBad.BiliClient.util;

public final class NextLayout {
    public static final String COLUMNS = "next_layout_columns";

    private NextLayout() { }

    public static int columns() {
        return Math.max(1, Math.min(3, SharedPreferencesUtil.getInt(COLUMNS, 2)));
    }
}
