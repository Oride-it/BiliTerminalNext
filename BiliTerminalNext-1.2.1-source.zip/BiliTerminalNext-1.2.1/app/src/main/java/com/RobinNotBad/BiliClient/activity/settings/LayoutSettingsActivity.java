package com.RobinNotBad.BiliClient.activity.settings;

import android.os.Bundle;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.RobinNotBad.BiliClient.R;
import com.RobinNotBad.BiliClient.activity.base.BaseActivity;
import com.RobinNotBad.BiliClient.theme.ThemeApplier;
import com.RobinNotBad.BiliClient.ui.widget.ChoiceCircleView;
import com.RobinNotBad.BiliClient.util.NextLayout;
import com.RobinNotBad.BiliClient.util.SharedPreferencesUtil;
import com.google.android.material.card.MaterialCardView;

public class LayoutSettingsActivity extends BaseActivity {
    private final ChoiceCircleView[] choices = new ChoiceCircleView[3];
    @Override protected void onCreate(Bundle state) {
        super.onCreate(state); setContentView(R.layout.activity_next_settings); setPageName("页面设置");
        LinearLayout content = findViewById(R.id.nextSettingsContent);
        String[] labels = {"单列", "双列", "三列"};
        int[] ids = {R.id.next_layout_single, R.id.next_layout_double, R.id.next_layout_triple};
        float density = getResources().getDisplayMetrics().density;
        for (int i = 0; i < 3; i++) {
            final int columns = i + 1;
            MaterialCardView card = new MaterialCardView(this); card.setId(ids[i]);
            card.setContentDescription(labels[i]);
            LinearLayout row = new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL);
            int pad = (int)(12*density); row.setPadding(pad, pad, pad, pad);
            TextView label = new TextView(this); label.setText(labels[i]); label.setTextSize(14);
            row.addView(label, new LinearLayout.LayoutParams(0, -2, 1));
            ChoiceCircleView check = new ChoiceCircleView(this);
            row.addView(check, new LinearLayout.LayoutParams((int)(28*density), (int)(28*density)));
            choices[i] = check; card.addView(row);
            card.setOnClickListener(v -> { SharedPreferencesUtil.putInt(NextLayout.COLUMNS, columns); updateSelection(); });
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, -2); params.bottomMargin = (int)(8*density);
            content.addView(card, params);
        }
        updateSelection(); ThemeApplier.applyContent(content);
    }
    private void updateSelection() {
        for (int i = 0; i < choices.length; i++) {
            boolean checked = NextLayout.columns() == i + 1;
            choices[i].setSelected(checked);
            findViewById(new int[]{R.id.next_layout_single, R.id.next_layout_double, R.id.next_layout_triple}[i]).setSelected(checked);
        }
    }
}
