package com.RobinNotBad.BiliClient.adapter;

import android.view.ViewGroup;
import android.view.Gravity;
import android.widget.FrameLayout;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.RobinNotBad.BiliClient.ui.widget.MenuCircleButton;
import com.RobinNotBad.BiliClient.util.MenuOrder;
import java.util.List;

public class MenuPlacementAdapter extends RecyclerView.Adapter<MenuPlacementAdapter.Holder> {
    public interface DragListener { void start(Holder holder); }
    private final List<String> keys;
    private DragListener dragListener;
    public MenuPlacementAdapter(List<String> keys) { this.keys = keys; setHasStableIds(true); }
    public void setDragListener(DragListener listener) { dragListener = listener; }
    @Override public long getItemId(int position) { return keys.get(position).hashCode(); }
    @NonNull @Override public Holder onCreateViewHolder(@NonNull ViewGroup parent, int type) {
        FrameLayout cell = new FrameLayout(parent.getContext());
        cell.setLayoutParams(new RecyclerView.LayoutParams(-1, -2));
        int gap = (int)(5*parent.getResources().getDisplayMetrics().density); cell.setPadding(gap,gap,gap,gap);
        MenuCircleButton button = new MenuCircleButton(parent.getContext());
        cell.addView(button, new FrameLayout.LayoutParams(-1, -2, Gravity.CENTER_HORIZONTAL));
        Holder holder = new Holder(cell, button);
        button.setOnLongClickListener(v -> { if (dragListener == null) return false; dragListener.start(holder); return true; });
        return holder;
    }
    @Override public void onBindViewHolder(@NonNull Holder holder, int position) {
        String key = keys.get(position); holder.button.setText(MenuOrder.label(key));
        holder.button.setIconResource(MenuOrder.icon(key));
        holder.button.setClickable(dragListener != null);
        holder.button.setLongClickable(dragListener != null);
    }
    @Override public int getItemCount() { return keys.size(); }
    public static class Holder extends RecyclerView.ViewHolder {
        public final MenuCircleButton button;
        Holder(FrameLayout cell, MenuCircleButton button) { super(cell); this.button = button; }
    }
}
