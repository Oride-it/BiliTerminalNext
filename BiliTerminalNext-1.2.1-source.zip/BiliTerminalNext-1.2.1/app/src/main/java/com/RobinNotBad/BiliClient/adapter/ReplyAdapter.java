package com.RobinNotBad.BiliClient.adapter;

import static com.RobinNotBad.BiliClient.util.StringUtil.toWan;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.TextUtils;
import android.text.style.RelativeSizeSpan;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.RobinNotBad.BiliClient.BiliTerminal;
import com.RobinNotBad.BiliClient.R;
import com.RobinNotBad.BiliClient.activity.ImageViewerActivity;
import com.RobinNotBad.BiliClient.activity.reply.ReplyInfoActivity;
import com.RobinNotBad.BiliClient.activity.reply.WriteReplyActivity;
import com.RobinNotBad.BiliClient.activity.user.info.UserInfoActivity;
import com.RobinNotBad.BiliClient.api.ReplyApi;
import com.RobinNotBad.BiliClient.listener.OnItemClickListener;
import com.RobinNotBad.BiliClient.model.Reply;
import com.RobinNotBad.BiliClient.model.UserInfo;
import com.RobinNotBad.BiliClient.ui.widget.RadiusBackgroundSpan;
import com.RobinNotBad.BiliClient.util.CenterThreadPool;
import com.RobinNotBad.BiliClient.util.GlideUtil;
import com.RobinNotBad.BiliClient.util.MsgUtil;
import com.RobinNotBad.BiliClient.util.SharedPreferencesUtil;
import com.RobinNotBad.BiliClient.util.StringUtil;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.DecodeFormat;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.request.RequestOptions;
import com.google.android.material.button.MaterialButton;

import org.json.JSONException;

import java.io.IOException;
import java.util.ArrayList;

//评论Adapter
//2023-07-22

@SuppressLint("ClickableViewAccessibility")
public class ReplyAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    public boolean isDetail = false;
    public boolean isManager = false;
    public long count = -1;
    final Context context;
    final ArrayList<Reply> replyList;
    final long oid;
    final long up_mid;
    final long root;
    final int type;
    public int sort;
    public final int replyType;
    OnItemClickListener listener;

    public ReplyAdapter(Context context, ArrayList<Reply> replyList, long oid, long root, int type, int sort,
                        long up_mid) {
        this.context = context;
        this.replyList = replyList;
        this.oid = oid;
        this.root = root;
        this.type = type;
        this.sort = sort;
        this.replyType = type;
        this.up_mid = up_mid;
    }

    public void setOnSortSwitchListener(OnItemClickListener listener) {
        this.listener = listener;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        if (viewType == 0) {
            View view = LayoutInflater.from(this.context).inflate(R.layout.cell_reply_action, parent, false);
            return new WriteReply(view);
        } else {
            View view = LayoutInflater.from(this.context).inflate(R.layout.cell_reply_list, parent, false);
            return new ReplyHolder(view);
        }
    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, @SuppressLint("RecyclerView") int position) {
        if (holder instanceof WriteReply) {
            WriteReply writeReply = (WriteReply) holder;
            writeReply.write_reply.setOnClickListener(view -> {
                Intent intent = new Intent();
                intent.setClass(context, WriteReplyActivity.class);
                intent.putExtra("oid", oid);
                intent.putExtra("rpid", root);
                intent.putExtra("parent", root);
                intent.putExtra("parentSender", "");
                intent.putExtra("replyType", replyType);
                context.startActivity(intent);
            });
            String[] sorts = {"未知排序", "未知排序", "时间排序", "热度排序"};
            if (isDetail) {
                writeReply.sort.setVisibility(View.GONE);
                writeReply.count_label.setVisibility(View.GONE);
            } else {
                writeReply.sort.setText(sorts[sort]);
                writeReply.sort.setOnClickListener(view -> {
                    if (this.listener != null)
                        listener.onItemClick(0);
                    writeReply.sort.setText(sorts[sort]);
                });
                writeReply.count_label.setText("共" + count + "条评论");
            }
        }
        if (holder instanceof ReplyHolder) {
            int realPosition;
            if (isDetail) {
                realPosition = position != 0 ? position - 1 : 0;
            } else {
                realPosition = position - 1;
            }
            if (realPosition < 0 || realPosition >= replyList.size())
                return;

            ReplyHolder replyHolder = (ReplyHolder) holder;
            Reply reply = replyList.get(realPosition);
            if (reply == null || reply.sender == null)
                return;

            if (!GlideUtil.url(reply.sender.avatar).equals(replyHolder.lastAvatarUrl)) {
                replyHolder.lastAvatarUrl = GlideUtil.url(reply.sender.avatar);
                Glide.with(BiliTerminal.context).asDrawable().load(GlideUtil.url(reply.sender.avatar))
                        .transition(GlideUtil.getTransitionOptions())
                        .placeholder(R.mipmap.akari)
                        .apply(RequestOptions.circleCropTransform())
                        .diskCacheStrategy(DiskCacheStrategy.NONE)
                        .into(replyHolder.replyAvatar);
            }

            UserInfo sender = reply.sender;
            SpannableStringBuilder name_str = new SpannableStringBuilder();

            // 大会员红字
            if (!TextUtils.isEmpty(sender.vip_nickname_color)
                    && !SharedPreferencesUtil.getBoolean(SharedPreferencesUtil.NO_VIP_COLOR, false))
                replyHolder.userName.setTextColor(Color.parseColor(sender.vip_nickname_color));

            // up主标识
            if (sender.mid == up_mid) {
                name_str.append(" UP ");
                name_str.append(reply.sender.name);
                name_str.setSpan(
                        new RadiusBackgroundSpan(2, (int) context.getResources().getDimension(R.dimen.round_small), com.RobinNotBad.BiliClient.theme.ThemeManager.palette().buttonTint, com.RobinNotBad.BiliClient.theme.ThemeManager.palette().accent),
                        0, 4, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                name_str.setSpan(new RelativeSizeSpan(0.8f), 0, 4, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            } else
                name_str.append(sender.name);
            int last_length = name_str.length();
            name_str.append(" ").append(String.valueOf(sender.level));
            if (sender.is_senior_member == 1)
                name_str.append("+");
            name_str.setSpan(StringUtil.getLevelBadge(context, sender), last_length + 1, name_str.length(),
                    Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);

            // 等级
            if (!TextUtils.isEmpty(sender.medal_name)) {
                last_length = name_str.length();
                name_str.append("  ").append(sender.medal_name).append("Lv").append(String.valueOf(sender.medal_level))
                        .append(" ");
                name_str.setSpan(
                        new RadiusBackgroundSpan(2, (int) context.getResources().getDimension(R.dimen.round_small),
                                com.RobinNotBad.BiliClient.theme.ThemeManager.palette().selectedText,
                                com.RobinNotBad.BiliClient.theme.ThemeManager.palette().accentLow),
                        last_length + 1, name_str.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                name_str.setSpan(new RelativeSizeSpan(0.8f), last_length + 1, name_str.length(),
                        Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            }

            replyHolder.userName.setText(name_str);

            if (SharedPreferencesUtil.getBoolean(SharedPreferencesUtil.REPLY_MARQUEE_NAME, true)) {
                replyHolder.userName.setSingleLine(true);
                replyHolder.userName.setMaxLines(1);
            } else {
                replyHolder.userName.setSingleLine(false);
                replyHolder.userName.setMaxLines(3);
            }

            replyHolder.message.setText(reply.message);
            StringUtil.setCopy(replyHolder.message);
            replyHolder.message.setOnTouchListener(new StringUtil.ClickableSpanTouchListener());

            replyHolder.likeCount.setText(toWan(reply.likeCount));

            if (reply.liked) {
                replyHolder.likeCount.setTextColor(com.RobinNotBad.BiliClient.theme.ThemeManager.palette().accent);
                replyHolder.likeCount.setCompoundDrawablesWithIntrinsicBounds(
                        ContextCompat.getDrawable(context, R.drawable.icon_reply_like1), null, null, null);
                com.RobinNotBad.BiliClient.theme.ThemeApplier.retintCompound(replyHolder.likeCount,
                        com.RobinNotBad.BiliClient.theme.ThemeManager.palette().accent);
            } else {
                replyHolder.likeCount.setTextColor(com.RobinNotBad.BiliClient.theme.ThemeManager.palette().textTransparent);
                replyHolder.likeCount.setCompoundDrawablesWithIntrinsicBounds(
                        ContextCompat.getDrawable(context, R.drawable.icon_reply_like0), null, null, null);
                com.RobinNotBad.BiliClient.theme.ThemeApplier.retintCompound(replyHolder.likeCount,
                        com.RobinNotBad.BiliClient.theme.ThemeManager.palette().textPrimary);
            }

            if (reply.childCount != 0 && !(realPosition == 0 && isDetail)) {
                replyHolder.childReplyCard.setVisibility(View.VISIBLE);

                if (reply.upReplied)
                    replyHolder.childCount.setText("UP主在内 共" + reply.childCount + "条回复");
                else
                    replyHolder.childCount.setText("共" + reply.childCount + "条回复");

                if (reply.childMsgList != null && replyHolder.childReplies != null) {
                    int childCount = reply.childMsgList.size();
                    int existingViewCount = replyHolder.childReplies.getChildCount();

                    for (int i = 0; i < childCount; i++) {
                        Reply child = reply.childMsgList.get(i);
                        if (child == null || child.sender == null)
                            continue;

                        SpannableStringBuilder childMsg = new SpannableStringBuilder();
                        if (child.sender.mid == up_mid) {
                            childMsg.append(" UP ");
                            childMsg.append(child.sender.name);
                            childMsg.setSpan(new RadiusBackgroundSpan(2, (int) context.getResources().getDimension(R.dimen.round_small), com.RobinNotBad.BiliClient.theme.ThemeManager.palette().buttonTint, com.RobinNotBad.BiliClient.theme.ThemeManager.palette().accent), 0, 4, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                            childMsg.setSpan(new RelativeSizeSpan(0.8f), 0, 4, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                        } else
                            childMsg.append(child.sender.name);

                        childMsg.append("：").append(child.message);

                        TextView textView;
                        if (i < existingViewCount) {
                            textView = (TextView) replyHolder.childReplies.getChildAt(i);
                            textView.setVisibility(View.VISIBLE);
                        } else {
                            @SuppressLint("InflateParams")
                            TextView newTextView = (TextView) LayoutInflater.from(context)
                                    .inflate(R.layout.cell_reply_child, null);
                            replyHolder.childReplies.addView(newTextView);
                            com.RobinNotBad.BiliClient.theme.ThemeApplier.applyContent(newTextView);
                            textView = newTextView;
                        }
                        textView.setText(childMsg);
                    }

                    for (int i = childCount; i < existingViewCount; i++) {
                        replyHolder.childReplies.getChildAt(i).setVisibility(View.GONE);
                    }
                }
            } else
                replyHolder.childReplyCard.setVisibility(View.GONE);

            if (reply.upLiked)
                replyHolder.upLiked.setVisibility(View.VISIBLE);
            else
                replyHolder.upLiked.setVisibility(View.GONE);

            replyHolder.pubDate.setText(reply.pubTime);

            if (reply.pictureList != null && !reply.pictureList.isEmpty()) {
                replyHolder.imageCard.setVisibility(View.VISIBLE);
                replyHolder.imageCount.setVisibility(View.VISIBLE);

                String firstImageUrl = GlideUtil.url(reply.pictureList.get(0));
                if (!firstImageUrl.equals(replyHolder.lastImageUrl)) {
                    replyHolder.lastImageUrl = firstImageUrl;
                    Glide.with(BiliTerminal.context).asDrawable().load(firstImageUrl)
                            .transition(GlideUtil.getTransitionOptions())
                            .placeholder(R.mipmap.placeholder)
                            .format(DecodeFormat.PREFER_RGB_565)
                            .diskCacheStrategy(DiskCacheStrategy.NONE)
                            .into(replyHolder.imageCard);
                }

                replyHolder.imageCount.setText("共" + reply.pictureList.size() + "张图片");
                replyHolder.imageCard.setOnClickListener(view -> {
                    Intent intent = new Intent();
                    intent.setClass(context, ImageViewerActivity.class);
                    intent.putExtra("imageList", reply.pictureList);
                    context.startActivity(intent);
                });
            } else {
                replyHolder.imageCount.setVisibility(View.GONE);
                replyHolder.imageCard.setVisibility(View.GONE);
            }

            replyHolder.childReplyCard.setOnClickListener(view -> startReplyInfoActivity(reply));
            if (!isDetail) {
                replyHolder.itemView.setOnClickListener((view) -> startReplyInfoActivity(reply));
                replyHolder.message.setOnClickListener((view) -> startReplyInfoActivity(reply));
            }

            replyHolder.replyAvatar.setOnClickListener(view -> {
                Intent intent = new Intent();
                intent.setClass(context, UserInfoActivity.class);
                intent.putExtra("mid", reply.sender.mid);
                context.startActivity(intent);
            });

            replyHolder.likeCount.setOnClickListener(view -> CenterThreadPool.run(() -> {
                if (SharedPreferencesUtil.getLong(SharedPreferencesUtil.mid, 0) == 0) {
                    ((Activity) context).runOnUiThread(() -> MsgUtil.showMsg("还没有登录喵~"));
                    return;
                }
                if (!reply.liked) {
                    try {
                        if (ReplyApi.likeReply(oid, reply.rpid, true) == 0) {
                            reply.liked = true;
                            ((Activity) context).runOnUiThread(() -> {
                                MsgUtil.showMsg("点赞成功");
                                replyHolder.likeCount.setText(toWan(++reply.likeCount));
                                replyHolder.likeCount.setTextColor(com.RobinNotBad.BiliClient.theme.ThemeManager.palette().accent);
                                replyHolder.likeCount.setCompoundDrawablesWithIntrinsicBounds(
                                        ContextCompat.getDrawable(context, R.drawable.icon_reply_like1), null, null,
                                        null);
                                com.RobinNotBad.BiliClient.theme.ThemeApplier.retintCompound(replyHolder.likeCount,
                                        com.RobinNotBad.BiliClient.theme.ThemeManager.palette().accent);
                            });
                        } else
                            ((Activity) context).runOnUiThread(() -> MsgUtil.showMsg("点赞失败"));
                    } catch (IOException e) {
                        e.printStackTrace();
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                } else {
                    try {
                        if (ReplyApi.likeReply(oid, reply.rpid, false) == 0) {
                            reply.liked = false;
                            ((Activity) context).runOnUiThread(() -> {
                                MsgUtil.showMsg("取消成功");
                                replyHolder.likeCount.setText(toWan(--reply.likeCount));
                                replyHolder.likeCount.setTextColor(com.RobinNotBad.BiliClient.theme.ThemeManager.palette().textTransparent);
                                replyHolder.likeCount.setCompoundDrawablesWithIntrinsicBounds(
                                        ContextCompat.getDrawable(context, R.drawable.icon_reply_like0), null, null,
                                        null);
                                com.RobinNotBad.BiliClient.theme.ThemeApplier.retintCompound(replyHolder.likeCount,
                                        com.RobinNotBad.BiliClient.theme.ThemeManager.palette().textPrimary);
                            });
                        } else
                            ((Activity) context).runOnUiThread(() -> MsgUtil.showMsg("取消失败"));
                    } catch (IOException e) {
                        e.printStackTrace();
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            }));

            // 删除按钮
            if (isManager || reply.sender.mid == SharedPreferencesUtil.getLong("mid", 0)) {
                View.OnClickListener onDeleteClick = view -> MsgUtil.showMsg("长按删除");
                replyHolder.item_reply_delete.setOnClickListener(onDeleteClick);
                View.OnLongClickListener onDeleteLongClick = new View.OnLongClickListener() {
                    private int longClickPosition = -1;
                    private long longClickTime = -1;

                    @Override
                    public boolean onLongClick(View view) {
                        long currentTime = System.currentTimeMillis();
                        if (longClickPosition == realPosition && currentTime - longClickTime < 6000) {
                            CenterThreadPool.run(() -> {
                                try {
                                    int result = ReplyApi.deleteReply(oid, reply.rpid, replyType);
                                    if (result == 0) {
                                        replyList.remove(realPosition);
                                        ((Activity) context).runOnUiThread(() -> {
                                            notifyItemRemoved(position);
                                            notifyItemRangeChanged(position, replyList.size() - position);
                                            longClickPosition = -1;
                                            MsgUtil.showMsg("删除成功~");
                                            if (realPosition == 0 && isDetail) {
                                                ((Activity) context).finish();
                                            }
                                        });
                                    } else {
                                        String msg = "操作失败：" + result;
                                        switch (result) {
                                            case -404:
                                                msg = "没有这条评论！";
                                                break;
                                            case -403:
                                                msg = "权限不足！";
                                                break;
                                        }
                                        String finalMsg = msg;
                                        ((Activity) context).runOnUiThread(() -> MsgUtil.showMsg(finalMsg));
                                    }
                                } catch (Exception e) {
                                    ((Activity) context).runOnUiThread(() -> MsgUtil.err(e));
                                }
                            });
                        } else {
                            longClickPosition = realPosition;
                            longClickTime = currentTime;
                            MsgUtil.showMsg("再次长按删除");
                        }
                        return true;
                    }
                };
                replyHolder.item_reply_delete.setOnLongClickListener(onDeleteLongClick);
                replyHolder.item_reply_delete.setVisibility(View.VISIBLE);
            } else
                replyHolder.item_reply_delete.setVisibility(View.GONE);

            // 回复按钮
            replyHolder.replyBtn.setOnClickListener(view -> {
                boolean noParent = isDetail && realPosition == 0;
                Intent intent = new Intent();
                intent.setClass(context, WriteReplyActivity.class);
                intent.putExtra("oid", oid);
                intent.putExtra("rpid", noParent ? root : reply.rpid);
                intent.putExtra("parent", noParent ? root : reply.rpid);
                intent.putExtra("replyType", replyType);
                intent.putExtra("pos", realPosition);
                if (root != 0 && !noParent)
                    intent.putExtra("parentSender", reply.sender.name);
                else
                    intent.putExtra("parentSender", "");
                context.startActivity(intent);
            });
        }
    }

    @Override
    public void onViewRecycled(@NonNull RecyclerView.ViewHolder holder) {
        if (holder instanceof ReplyHolder) {
            ReplyHolder replyHolder = (ReplyHolder) holder;
            replyHolder.lastAvatarUrl = null;
            replyHolder.lastImageUrl = null;
        }
        super.onViewRecycled(holder);
    }

    public void startReplyInfoActivity(Reply reply) {
        if (reply == null)
            return;
        long rpid = reply.rpid;
        long oid = reply.oid;
        Intent intent = new Intent();
        intent.setClass(context, ReplyInfoActivity.class);
        intent.putExtra("rpid", rpid);
        intent.putExtra("oid", oid);
        intent.putExtra("type", replyType);
        intent.putExtra("up_mid", up_mid);
        intent.putExtra("is_manager", isManager);
        context.startActivity(intent);
    }

    @Override
    public int getItemCount() {
        return replyList != null ? replyList.size() + 1 : 1;
    }

    @Override
    public int getItemViewType(int position) {
        if (isDetail && position == 1) {
            return 0;
        } else if (!isDetail && position == 0) {
            return 0;
        }
        return 1;
    }

    public static class ReplyHolder extends RecyclerView.ViewHolder {
        final ImageView replyAvatar;
        final ImageView dislikeBtn;
        final LinearLayout childReplies;
        final TextView message;
        final TextView userName;
        final TextView pubDate;
        final TextView childCount;
        final TextView likeCount;
        final TextView replyBtn;
        final TextView upLiked;
        final TextView imageCount;
        final TextView item_reply_delete;
        final LinearLayout childReplyCard;
        final ImageView imageCard;
        String lastAvatarUrl;
        String lastImageUrl;

        public ReplyHolder(@NonNull View itemView) {
            super(itemView);

            replyAvatar = itemView.findViewById(R.id.replyAvatar);
            dislikeBtn = itemView.findViewById(R.id.dislikeBtn);
            childReplies = itemView.findViewById(R.id.repliesList);
            message = itemView.findViewById(R.id.replyText);
            userName = itemView.findViewById(R.id.replyUsername);
            pubDate = itemView.findViewById(R.id.replyPubDate);
            childCount = itemView.findViewById(R.id.repliesControl);
            likeCount = itemView.findViewById(R.id.likes);
            replyBtn = itemView.findViewById(R.id.replyBtn);
            upLiked = itemView.findViewById(R.id.upLiked);
            childReplyCard = itemView.findViewById(R.id.repliesCard);
            imageCount = itemView.findViewById(R.id.imageCount);
            imageCard = itemView.findViewById(R.id.imageCard);
            item_reply_delete = itemView.findViewById(R.id.item_reply_delete);
        }
    }

    public static class WriteReply extends RecyclerView.ViewHolder {
        final MaterialButton write_reply;
        final MaterialButton sort;
        final TextView count_label;

        public WriteReply(@NonNull View itemView) {
            super(itemView);

            write_reply = itemView.findViewById(R.id.write_reply);
            sort = itemView.findViewById(R.id.sort);
            count_label = itemView.findViewById(R.id.count_label);
        }
    }
}
