package com.RobinNotBad.BiliClient.ui.widget;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.view.View;
import com.RobinNotBad.BiliClient.R;
import com.RobinNotBad.BiliClient.theme.ThemeManager;

/** Circular selection control, or a circular color swatch with a selection ring. */
public class ChoiceCircleView extends View {
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private Integer color;
    public ChoiceCircleView(Context context) {
        super(context);
        setTag(R.id.theme_no_tint, Boolean.TRUE);
    }
    public void setColor(int color) { this.color = color; invalidate(); }
    @Override public void setSelected(boolean selected) { super.setSelected(selected); invalidate(); }
    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float cx = getWidth()/2f, cy = getHeight()/2f;
        float radius = Math.min(getWidth(), getHeight()) * .38f;
        float stroke = Math.max(1, getResources().getDisplayMetrics().density * 1.5f);
        paint.setStrokeWidth(stroke);
        paint.setStyle(color != null || isSelected() ? Paint.Style.FILL : Paint.Style.STROKE);
        paint.setColor(color != null ? color : isSelected() ? ThemeManager.palette().accent : ThemeManager.palette().textSecondary);
        canvas.drawCircle(cx, cy, radius, paint);
        if (color != null && isSelected()) {
            paint.setStyle(Paint.Style.STROKE); paint.setColor(ThemeManager.palette().textPrimary);
            canvas.drawCircle(cx, cy, radius + stroke*2, paint);
        } else if (isSelected()) {
            paint.setStyle(Paint.Style.STROKE); paint.setColor(
                    androidx.core.graphics.ColorUtils.calculateLuminance(ThemeManager.palette().accent) > .4 ? 0xFF242027 : 0xFFFFFFFF);
            paint.setStrokeCap(Paint.Cap.ROUND); paint.setStrokeJoin(Paint.Join.ROUND);
            Path check = new Path(); check.moveTo(cx-radius*.45f, cy);
            check.lineTo(cx-radius*.08f, cy+radius*.35f); check.lineTo(cx+radius*.5f, cy-radius*.35f);
            canvas.drawPath(check, paint);
        }
    }
}
