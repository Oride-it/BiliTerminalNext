package com.RobinNotBad.BiliClient.activity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.constraintlayout.utils.widget.ImageFilterView;

import com.RobinNotBad.BiliClient.R;
import com.RobinNotBad.BiliClient.activity.base.BaseActivity;
import com.RobinNotBad.BiliClient.helper.TutorialHelper;
import com.RobinNotBad.BiliClient.model.Tutorial;
import com.RobinNotBad.BiliClient.util.SharedPreferencesUtil;
import com.google.android.material.button.MaterialButton;

import java.util.Locale;
import androidx.core.util.ObjectsCompat;

public class TutorialActivity extends BaseActivity {

    @SuppressLint("UseCompatLoadingForDrawables")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        asyncInflate(R.layout.activity_tutorial, (layoutView, resId) -> {

            Intent intent = getIntent();

            Tutorial tutorial = ObjectsCompat.requireNonNull(TutorialHelper.loadTutorial(getResources().getXml(intent.getIntExtra("xml_id", R.xml.tutorial_recommend))));

            ((TextView) findViewById(R.id.text_title)).setText(tutorial.name);
            ((TextView) findViewById(R.id.content)).setText(TutorialHelper.loadText(tutorial.content));

            try {
                if (tutorial.imgid != null) {
                    int indentify = getResources().getIdentifier(getPackageName() + ":" + tutorial.imgid, null, null);
                    if (indentify > 0)
                        ((ImageFilterView) findViewById(R.id.image_view)).setImageDrawable(getResources().getDrawable(indentify));
                } else findViewById(R.id.image_view).setVisibility(View.GONE);
            } catch (Exception e) {
                e.printStackTrace();
            }

            MaterialButton close_btn = findViewById(R.id.close_btn);
            close_btn.setText("已阅");
            close_btn.setEnabled(true);
            close_btn.setOnClickListener(view -> {
                SharedPreferencesUtil.putInt("tutorial_ver_" + intent.getStringExtra("tag"), intent.getIntExtra("version", -1));
                finish();
            });

            View scrollView = findViewById(R.id.scrollView);
            scrollView.setFocusable(true);
            scrollView.setFocusableInTouchMode(true);
            scrollView.requestFocus();
        });
    }

    @Override
    public void onBackPressed() {
    }
}
