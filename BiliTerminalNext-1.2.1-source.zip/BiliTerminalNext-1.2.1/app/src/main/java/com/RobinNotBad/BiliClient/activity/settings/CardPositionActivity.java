package com.RobinNotBad.BiliClient.activity.settings;

import android.os.Bundle;
import android.content.Intent;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.GridLayoutManager;
import com.RobinNotBad.BiliClient.R;
import com.RobinNotBad.BiliClient.activity.base.BaseActivity;
import com.RobinNotBad.BiliClient.adapter.MenuPlacementAdapter;
import com.RobinNotBad.BiliClient.theme.ThemeApplier;
import com.RobinNotBad.BiliClient.util.MenuOrder;
import com.RobinNotBad.BiliClient.util.NextLayout;
import com.google.android.material.button.MaterialButton;

public class CardPositionActivity extends BaseActivity {
    private RecyclerView preview;
    @Override protected void onCreate(Bundle state) {
        super.onCreate(state); setContentView(R.layout.activity_next_settings); setPageName("卡片位置设置");
        LinearLayout content = findViewById(R.id.nextSettingsContent);
        TextView title = new TextView(this); title.setText("目前的样子");
        title.setPadding(8, 8, 8, 12); content.addView(title);
        preview = new RecyclerView(this); preview.setId(R.id.next_card_preview);
        preview.setNestedScrollingEnabled(false); preview.setItemAnimator(null);
        content.addView(preview, new LinearLayout.LayoutParams(-1, -2));
        MaterialButton change = new MaterialButton(this); change.setId(R.id.next_card_edit); change.setText("更换模式");
        change.setOnClickListener(v -> startActivity(new Intent(this, CardSortActivity.class)));
        content.addView(change); ThemeApplier.applyContent(content);
    }
    @Override protected void onResume() {
        super.onResume();
        if (preview != null) {
            preview.setLayoutManager(new GridLayoutManager(this, NextLayout.columns()));
            preview.setAdapter(new MenuPlacementAdapter(MenuOrder.visible()));
        }
    }
}
