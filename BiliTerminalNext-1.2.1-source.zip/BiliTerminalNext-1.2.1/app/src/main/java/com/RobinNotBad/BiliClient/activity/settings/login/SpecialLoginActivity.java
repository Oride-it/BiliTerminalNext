package com.RobinNotBad.BiliClient.activity.settings.login;

import android.annotation.SuppressLint;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.RobinNotBad.BiliClient.BiliTerminal;
import com.RobinNotBad.BiliClient.R;
import com.RobinNotBad.BiliClient.activity.SplashActivity;
import com.RobinNotBad.BiliClient.activity.base.BaseActivity;
import com.RobinNotBad.BiliClient.util.Logu;
import com.RobinNotBad.BiliClient.util.MsgUtil;
import com.RobinNotBad.BiliClient.util.NetWorkUtil;
import com.RobinNotBad.BiliClient.util.SharedPreferencesUtil;
import com.google.android.material.card.MaterialCardView;

import org.json.JSONException;
import org.json.JSONObject;

public class SpecialLoginActivity extends BaseActivity {

    private EditText textInput;

    @SuppressLint({"MissingInflatedId", "SetTextI18n"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        com.RobinNotBad.BiliClient.util.AccountStore.saveCurrent();
        setContentView(R.layout.activity_login_special);
        Logu.i("debug", "使用特殊登录方式");

        textInput = findViewById(R.id.loginInput);
        MaterialCardView confirm = findViewById(R.id.confirm);
        MaterialCardView refuse = findViewById(R.id.refuse);
        MaterialCardView copy = findViewById(R.id.copy);
        TextView desc = findViewById(R.id.desc);

        Intent intent = getIntent();

        if (intent.getBooleanExtra("login", true)) {
            refuse.setOnClickListener(v -> {
                if (getIntent().getBooleanExtra("from_setup", false))
                    startActivity(new Intent(this, SplashActivity.class));
                else finish();
            });

            confirm.setOnClickListener(view -> {
                String loginInfo = textInput.getText().toString();
                try {
                    JSONObject jsonObject = new JSONObject(loginInfo);
                    String cookies = jsonObject.getString("cookies");
                    long accountId = Long.parseLong(NetWorkUtil.getInfoFromCookie("DedeUserID", cookies));
                    String csrf = NetWorkUtil.getInfoFromCookie("bili_jct", cookies);
                    String refreshToken = jsonObject.getString("refresh_token");
                    if (accountId <= 0 || csrf.isEmpty()) throw new JSONException("Invalid login data");
                    SharedPreferencesUtil.putLong(SharedPreferencesUtil.mid, accountId);
                    SharedPreferencesUtil.putString(SharedPreferencesUtil.csrf, csrf);
                    SharedPreferencesUtil.putString(SharedPreferencesUtil.cookies, cookies);
                    SharedPreferencesUtil.putString(SharedPreferencesUtil.refresh_token, refreshToken);
                    runOnUiThread(() -> MsgUtil.showMsg("登录成功！"));
                    SharedPreferencesUtil.putBoolean(SharedPreferencesUtil.setup, true);

                    NetWorkUtil.refreshHeaders();
                    com.RobinNotBad.BiliClient.util.AccountStore.saveCurrent();

                    Intent intent1 = new Intent();
                    intent1.setClass(SpecialLoginActivity.this, SplashActivity.class);
                    if (getIntent().getBooleanExtra("add_account", false)) {
                        com.RobinNotBad.BiliClient.util.AccountStore.openMySpace(this);
                    } else startActivity(intent1);
                    finish();
                } catch (JSONException | NumberFormatException e) {
                    runOnUiThread(() -> MsgUtil.showMsg("请检查输入的内容，不要有多余空格或字符"));
                }
            });
        } else {
            desc.setText(R.string.special_login_export);

            JSONObject jsonObject = new JSONObject();
            try {
                jsonObject.put("cookies", SharedPreferencesUtil.getString("cookies", ""));
                jsonObject.put("refresh_token", SharedPreferencesUtil.getString(SharedPreferencesUtil.refresh_token, ""));
            } catch (JSONException e) {
                e.printStackTrace();
            }
            textInput.setText(jsonObject.toString());
            textInput.clearFocus();

            refuse.setVisibility(View.GONE);
            if (BiliTerminal.isDebugBuild()) {
                confirm.setOnClickListener(v -> {
                    try {
                        JSONObject input = new JSONObject(textInput.getText().toString());
                        String cookies = input.getString("cookies");
                        SharedPreferencesUtil.putString(SharedPreferencesUtil.cookies, cookies);
                        runOnUiThread(() -> MsgUtil.showMsg("导入cookies成功"));

                        NetWorkUtil.refreshHeaders();
                    } catch (JSONException e) {
                        runOnUiThread(() -> MsgUtil.showMsg("请检查输入的内容，不要有多余空格或字符"));
                    }
                });
            } else confirm.setVisibility(View.GONE);
            copy.setOnClickListener((view) -> {
                ClipboardManager clipboardManager = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                ClipData clipData = ClipData.newPlainText("label", textInput.getText());
                clipboardManager.setPrimaryClip(clipData);
                MsgUtil.showMsg("已复制");
            });
        }
    }

}
