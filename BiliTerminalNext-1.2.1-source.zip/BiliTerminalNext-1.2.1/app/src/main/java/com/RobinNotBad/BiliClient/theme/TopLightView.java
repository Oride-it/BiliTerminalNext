package com.RobinNotBad.BiliClient.theme;

import android.app.Activity;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;

import com.RobinNotBad.BiliClient.R;

/** A static, touch-through light falling from the top centre on every screen. */
public final class TopLightView extends View {
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);

    public TopLightView(Context context) {
        super(context);
        setClickable(false);
        setFocusable(false);
        if (android.os.Build.VERSION.SDK_INT >= 16) {
            setImportantForAccessibility(IMPORTANT_FOR_ACCESSIBILITY_NO);
        }
        setTag(R.id.theme_no_tint, Boolean.TRUE);
    }

    public static void attach(Activity activity) {
        ViewGroup content = activity.findViewById(android.R.id.content);
        if (!(content instanceof FrameLayout)) return;
        View existing = content.findViewById(R.id.next_top_light);
        if (existing != null) {
            existing.invalidate();
            if (content.indexOfChild(existing) != 0) {
                ViewGroup.LayoutParams params = existing.getLayoutParams();
                content.removeView(existing); content.addView(existing, 0, params);
            }
            return;
        }
        TopLightView light = new TopLightView(activity);
        light.setId(R.id.next_top_light);
        content.addView(light, 0, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (getWidth() == 0 || getHeight() == 0) return;
        int color = ThemeManager.getPersonalColor();
        int red = (int)(android.graphics.Color.red(color)*.315f);
        int green = (int)(android.graphics.Color.green(color)*.28f);
        int blue = (int)(android.graphics.Color.blue(color)*.315f);
        int glow = android.graphics.Color.rgb(red, green, blue);
        int middle = androidx.core.graphics.ColorUtils.blendARGB(android.graphics.Color.BLACK, glow, .64f);
        int low = androidx.core.graphics.ColorUtils.blendARGB(android.graphics.Color.BLACK, glow, .30f);
        float radius = getWidth()*1.1f;
        float centerY = getHeight()*.18f;
        RadialGradient light = new RadialGradient(getWidth()/2f, 0, radius,
                new int[]{glow, glow, middle, low, android.graphics.Color.BLACK},
                new float[]{0, .2f, .4f, .7f, 1}, Shader.TileMode.CLAMP);
        Matrix matrix = new Matrix();
        matrix.setScale(1, getHeight()*.72f/radius);
        matrix.postTranslate(0, centerY);
        light.setLocalMatrix(matrix); paint.setShader(light);
        canvas.drawRect(0, 0, getWidth(), getHeight(), paint);
    }
}
