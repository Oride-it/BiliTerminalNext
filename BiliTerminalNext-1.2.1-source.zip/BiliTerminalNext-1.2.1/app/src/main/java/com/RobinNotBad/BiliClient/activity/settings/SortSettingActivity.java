package com.RobinNotBad.BiliClient.activity.settings;

/** The existing menu-settings entry opens the same grid editor. */
public class SortSettingActivity extends CardSortActivity { }
