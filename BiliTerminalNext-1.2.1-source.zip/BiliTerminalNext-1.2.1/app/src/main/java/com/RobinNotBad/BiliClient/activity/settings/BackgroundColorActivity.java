package com.RobinNotBad.BiliClient.activity.settings;

import android.os.Bundle;
import android.graphics.drawable.GradientDrawable;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import com.RobinNotBad.BiliClient.R;
import com.RobinNotBad.BiliClient.activity.base.BaseActivity;
import com.RobinNotBad.BiliClient.event.ThemeChangedEvent;
import com.RobinNotBad.BiliClient.theme.ThemeApplier;
import com.RobinNotBad.BiliClient.theme.ThemeManager;
import com.RobinNotBad.BiliClient.theme.TopLightView;
import com.RobinNotBad.BiliClient.ui.widget.ChoiceCircleView;
import com.google.android.material.button.MaterialButton;

public class BackgroundColorActivity extends BaseActivity {
    private final int[] colors = {0xFFFB7299, 0xFFFF87B2, 0xFFFF6678, 0xFFFF9A75,
            0xFFFFC565, 0xFFB7D971, 0xFF69D6AA, 0xFF60D4D0,
            0xFF66CCFF, 0xFF7EAAFF, 0xFFB59BFF, 0xFFD391DC};
    private final String[] names = {"哔哩粉", "樱花粉", "珊瑚红", "蜜桃橙", "暖阳黄", "青柠绿",
            "薄荷绿", "湖水青", "晴空蓝", "雾蓝", "浅紫", "兰花紫"};
    private final ChoiceCircleView[] swatches = new ChoiceCircleView[12];
    private EditText hex;
    private ChoiceCircleView preview;
    private int pendingColor;
    @Override protected void onCreate(Bundle state) {
        super.onCreate(state); setContentView(R.layout.activity_next_settings); setPageName("颜色设置");
        LinearLayout content = findViewById(R.id.nextSettingsContent);
        float density = getResources().getDisplayMetrics().density;
        pendingColor = state == null ? ThemeManager.getPersonalColor() : state.getInt("pending_color", ThemeManager.getPersonalColor());
        for (int rowIndex = 0; rowIndex < 3; rowIndex++) {
            LinearLayout row = new LinearLayout(this); content.addView(row, new LinearLayout.LayoutParams(-1, -2));
            for (int col = 0; col < 4; col++) {
                int index = rowIndex * 4 + col;
                FrameLayout cell = new FrameLayout(this);
                ChoiceCircleView swatch = new ChoiceCircleView(this); swatch.setColor(colors[index]);
                swatch.setContentDescription(names[index]);
                swatch.setOnClickListener(v -> hex.setText(String.format(java.util.Locale.ROOT, "#%06X", colors[index] & 0xFFFFFF)));
                cell.addView(swatch, new FrameLayout.LayoutParams((int)(44*density), (int)(44*density), Gravity.CENTER));
                row.addView(cell, new LinearLayout.LayoutParams(0, (int)(64*density), 1));
                swatches[index] = swatch;
            }
        }
        LinearLayout custom = new LinearLayout(this); custom.setGravity(Gravity.CENTER_VERTICAL);
        custom.setPadding(0, (int)(20*density), 0, (int)(10*density)); content.addView(custom);
        hex = new EditText(this); hex.setId(R.id.next_color_hex); hex.setTag(R.id.theme_no_tint, Boolean.TRUE);
        hex.setSingleLine(true); hex.setHint("#FB7299"); hex.setTextSize(14);
        hex.setPadding((int)(12*density), (int)(10*density), (int)(8*density), (int)(10*density));
        custom.addView(hex, new LinearLayout.LayoutParams(0, (int)(54*density), 1));
        preview = new ChoiceCircleView(this); preview.setId(R.id.next_color_preview);
        LinearLayout.LayoutParams previewParams = new LinearLayout.LayoutParams((int)(48*density), (int)(48*density));
        previewParams.leftMargin = (int)(12*density); custom.addView(preview, previewParams);
        hex.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (s.toString().trim().matches("#[0-9a-fA-F]{6}")) {
                    pendingColor = android.graphics.Color.parseColor(s.toString().trim()); updatePreview();
                }
            }
            public void afterTextChanged(Editable value) { }
        });
        hex.setText(String.format(java.util.Locale.ROOT, "#%06X", pendingColor & 0xFFFFFF));
        MaterialButton save = new MaterialButton(this); save.setId(R.id.next_color_save); save.setText("保存");
        save.setOnClickListener(v -> {
            String value = hex.getText().toString().trim();
            if (!value.matches("#[0-9a-fA-F]{6}")) { hex.setError("请输入 # 加六位颜色值"); return; }
            int selected = android.graphics.Color.parseColor(value);
            ThemeManager.getInstance().setPersonalColor(selected);
            com.RobinNotBad.BiliClient.util.MsgUtil.showMsg("颜色已保存"); refreshTheme();
        }); content.addView(save);
        updatePreview(); ThemeApplier.applyContent(content);
    }
    private void updatePreview() {
        if (preview == null) return;
        preview.setColor(pendingColor);
        GradientDrawable box = new GradientDrawable();
        box.setColor(androidx.core.graphics.ColorUtils.blendARGB(ThemeManager.palette().windowBackground, pendingColor, .2f));
        box.setStroke(Math.max(1, (int)getResources().getDisplayMetrics().density), pendingColor);
        box.setCornerRadius(6 * getResources().getDisplayMetrics().density);
        androidx.core.view.ViewCompat.setBackground(hex, box); hex.setTextColor(ThemeManager.palette().textPrimary);
        for (int i = 0; i < swatches.length; i++) swatches[i].setSelected(colors[i] == pendingColor);
    }
    private void refreshTheme() {
        ThemeApplier.setupWindow(this); ThemeApplier.applyContent(findViewById(android.R.id.content));
        TopLightView.attach(this); updatePreview();
    }
    @Override public void onEvent(ThemeChangedEvent event) { if (!isDestroyed()) refreshTheme(); }
    @Override protected void onSaveInstanceState(Bundle state) { state.putInt("pending_color", pendingColor); super.onSaveInstanceState(state); }
}
