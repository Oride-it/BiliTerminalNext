package com.RobinNotBad.BiliClient.ui.widget;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.LinearGradient;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.text.TextUtils;
import com.RobinNotBad.BiliClient.R;
import com.RobinNotBad.BiliClient.theme.ThemeManager;
import com.google.android.material.button.MaterialButton;

/** Icon inside a quiet charcoal circle, with the label outside underneath. */
public class MenuCircleButton extends MaterialButton {
    private final Paint circlePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint labelPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint badgePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private float diameter, top, labelBaseline;
    public MenuCircleButton(Context context) {
        super(context);
        setTag(R.id.theme_no_tint, Boolean.TRUE);
        setInsetTop(0); setInsetBottom(0); setStrokeWidth(0);
        setMinWidth(0); setMinHeight(0); setMinimumWidth(0); setMinimumHeight(0);
        setPadding(0, 0, 0, 0); setAllCaps(false);
        androidx.core.view.ViewCompat.setBackground(this, null);
        androidx.core.view.ViewCompat.setElevation(this, 0);
        if (android.os.Build.VERSION.SDK_INT >= 21) setStateListAnimator(null);
        labelPaint.setTypeface(Typeface.create("sans-serif", Typeface.NORMAL));
        labelPaint.setTextAlign(Paint.Align.CENTER);
        badgePaint.setTextAlign(Paint.Align.CENTER);
    }
    @Override protected void onMeasure(int widthSpec, int heightSpec) {
        int width = MeasureSpec.getSize(widthSpec);
        float density = getResources().getDisplayMetrics().density;
        float scaled = getResources().getDisplayMetrics().scaledDensity;
        int columns = com.RobinNotBad.BiliClient.util.NextLayout.columns();
        diameter = Math.min(width * (columns == 1 ? .32f : columns == 2 ? .58f : .76f), 96*density);
        top = 10*density;
        labelPaint.setTextSize((columns == 3 ? 12 : 14)*scaled);
        Paint.FontMetrics font = labelPaint.getFontMetrics();
        labelBaseline = top + diameter + 10*density - font.ascent;
        setMeasuredDimension(width, (int)Math.ceil(labelBaseline + font.descent - 2*density));
        circlePaint.setShader(new LinearGradient(0, top, 0, top+diameter,
                0xCC2E2C2D, 0xCC292426, Shader.TileMode.CLAMP));
    }
    @Override protected void onDraw(Canvas canvas) {
        float cx = getWidth()/2f, cy = top+diameter/2;
        canvas.drawCircle(cx, cy, diameter/2, circlePaint);
        if (isPressed()) {
            badgePaint.setColor(0x18FFFFFF);
            canvas.drawCircle(cx, cy, diameter/2, badgePaint);
        }
        int textColor = ThemeManager.palette().textPrimary;
        Drawable icon = getIcon();
        if (icon != null) {
            int half = (int)(diameter*.27f);
            androidx.core.graphics.drawable.DrawableCompat.setTint(icon, textColor);
            icon.setBounds((int)cx-half, (int)cy-half, (int)cx+half, (int)cy+half);
            icon.draw(canvas);
        }
        String label = getText() == null ? "" : getText().toString();
        String badge = null;
        int split = label.lastIndexOf(" (");
        if (split >= 0 && label.endsWith(")")) {
            badge = label.substring(split+2, label.length()-1); label = label.substring(0, split);
            try { if (Integer.parseInt(badge) > 99) badge = "99+"; } catch (NumberFormatException ignored) { }
        }
        labelPaint.setColor(textColor);
        String visible = TextUtils.ellipsize(label, new android.text.TextPaint(labelPaint),
                Math.max(1, getWidth()-4), TextUtils.TruncateAt.END).toString();
        canvas.drawText(visible, cx, labelBaseline, labelPaint);
        if (badge != null) {
            float density = getResources().getDisplayMetrics().density;
            badgePaint.setTypeface(Typeface.create("sans-serif", Typeface.NORMAL));
            badgePaint.setTextSize(11*getResources().getDisplayMetrics().scaledDensity);
            float width = Math.max(22*density, badgePaint.measureText(badge)+10*density);
            float height = 21*density, right = cx+diameter*.48f, y = top;
            badgePaint.setColor(0xFFFF5797);
            canvas.drawRoundRect(new android.graphics.RectF(right-width, y, right, y+height),
                    5*density, 5*density, badgePaint);
            badgePaint.setColor(0xFFFFFFFF);
            canvas.drawText(badge, right-width/2, y+height/2-(badgePaint.ascent()+badgePaint.descent())/2, badgePaint);
        }
    }
}
