package com.RobinNotBad.BiliClient.util;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

import com.RobinNotBad.BiliClient.activity.user.MySpaceActivity;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/** Account snapshots stay in the app's private preferences; never log credentials. */
public final class AccountStore {
    private static final String ACCOUNTS = "next_accounts";
    private static final String[] STRINGS = {"cookies", "csrf", "refresh_token", "access_key"};

    private AccountStore() { }

    public static synchronized JSONArray list() {
        try {
            return new JSONArray(SharedPreferencesUtil.getString(ACCOUNTS, "[]"));
        } catch (JSONException ignored) {
            return new JSONArray();
        }
    }

    public static synchronized void saveCurrent() {
        long mid = SharedPreferencesUtil.getLong(SharedPreferencesUtil.mid, 0);
        String cookies = SharedPreferencesUtil.getString(SharedPreferencesUtil.cookies, "");
        if (mid == 0 || cookies.isEmpty()) return;
        // During QR polling the cookie may already belong to the new account.
        // Do not overwrite the previous account until login has completed.
        java.util.regex.Matcher cookieId = java.util.regex.Pattern
                .compile("(?:^|;\\s*)DedeUserID=([^;]+)").matcher(cookies);
        String cookieMid = cookieId.find() ? cookieId.group(1).trim() : "";
        if (!String.valueOf(mid).equals(cookieMid)) return;
        JSONArray accounts = list();
        JSONObject account = null;
        for (int i = 0; i < accounts.length(); i++) {
            JSONObject item = accounts.optJSONObject(i);
            if (item != null && item.optLong("mid") == mid) account = item;
        }
        try {
            if (account == null) {
                account = new JSONObject();
                account.put("mid", mid);
                accounts.put(account);
            }
            for (String key : STRINGS) account.put(key, SharedPreferencesUtil.getString(key, ""));
            account.put("cookie_refresh", SharedPreferencesUtil.getBoolean("cookie_refresh", true));
            SharedPreferencesUtil.putString(ACCOUNTS, accounts.toString());
        } catch (JSONException e) {
            throw new IllegalStateException("Unable to save account", e);
        }
    }

    public static synchronized void updateName(long mid, String name) {
        updateProfile(mid, name, null);
    }

    public static synchronized void updateProfile(long mid, String name, String avatar) {
        saveCurrent();
        JSONArray accounts = list();
        try {
            for (int i = 0; i < accounts.length(); i++) {
                JSONObject item = accounts.optJSONObject(i);
                if (item != null && item.optLong("mid") == mid) {
                    item.put("name", name);
                    if (avatar != null && !avatar.isEmpty()) item.put("avatar", avatar);
                }
            }
            SharedPreferencesUtil.putString(ACCOUNTS, accounts.toString());
        } catch (JSONException ignored) { }
    }

    public static synchronized boolean select(long mid) {
        saveCurrent();
        JSONArray accounts = list();
        for (int i = 0; i < accounts.length(); i++) {
            JSONObject account = accounts.optJSONObject(i);
            if (account == null || account.optLong("mid") != mid || account.optString("cookies").isEmpty()) continue;
            SharedPreferences.Editor editor = SharedPreferencesUtil.sharedPreferences.edit();
            for (String key : STRINGS) editor.putString(key, account.optString(key));
            editor.putLong("mid", mid)
                    .putBoolean("cookie_refresh", account.optBoolean("cookie_refresh", true))
                    .putInt(SharedPreferencesUtil.DYNAMIC_UPDATE_NUM, 0)
                    .putInt(SharedPreferencesUtil.MESSAGE_UPDATE_NUM, 0)
                    .remove("dynamic_update_baseline").apply();
            NetWorkUtil.refreshHeaders();
            return true;
        }
        return false;
    }

    public static synchronized void remove(long mid) {
        JSONArray previous = list();
        JSONArray next = new JSONArray();
        for (int i = 0; i < previous.length(); i++) {
            JSONObject item = previous.optJSONObject(i);
            if (item != null && item.optLong("mid") != mid) next.put(item);
        }
        SharedPreferencesUtil.putString(ACCOUNTS, next.toString());
    }

    public static void openMySpace(Context context) {
        Intent intent = new Intent(context, MySpaceActivity.class);
        intent.putExtra("from", "myspace");
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        context.startActivity(intent);
    }
}
