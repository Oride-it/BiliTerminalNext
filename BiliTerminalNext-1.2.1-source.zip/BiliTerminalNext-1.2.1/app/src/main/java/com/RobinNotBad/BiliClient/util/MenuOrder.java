package com.RobinNotBad.BiliClient.util;

import com.RobinNotBad.BiliClient.R;
import com.RobinNotBad.BiliClient.activity.MenuActivity;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

/** Menu placement is independent of the startup page and video list layout. */
public final class MenuOrder {
    public static final String KEY = "next_menu_order";
    private MenuOrder() { }
    public static List<String> all() {
        List<String> result = new ArrayList<>();
        String saved = SharedPreferencesUtil.getString(KEY,
                SharedPreferencesUtil.getString(SharedPreferencesUtil.MENU_SORT, ""));
        for (String key : saved.split(";")) {
            if ((MenuActivity.btnNames.containsKey(key) || "exit".equals(key)) && !result.contains(key)) result.add(key);
        }
        for (String key : MenuActivity.btnNames.keySet()) if (!result.contains(key)) result.add(key);
        if (!result.contains("exit")) result.add("exit");
        return result;
    }
    public static List<String> visible() {
        List<String> result = new ArrayList<>();
        boolean loggedIn = SharedPreferencesUtil.getLong("mid", 0) != 0;
        for (String key : all()) {
            if (!loggedIn && (key.equals("dynamic") || key.equals("message"))) continue;
            if ((key.equals("popular") || key.equals("precious") || key.equals("ranking")
                    || key.equals("live") || key.equals("timeline"))
                    && !SharedPreferencesUtil.getBoolean("menu_" + key, key.equals("popular"))) continue;
            result.add(!loggedIn && key.equals("myspace") ? "login" : key);
        }
        return result;
    }
    public static void saveVisible(List<String> visible) {
        List<String> canonical = new ArrayList<>();
        for (String key : visible) canonical.add(key.equals("login") ? "myspace" : key);
        if (new HashSet<>(canonical).size() != canonical.size()) return;
        List<String> full = all();
        if (!full.containsAll(canonical)) return;
        int index = 0;
        for (int i = 0; i < full.size(); i++) if (canonical.contains(full.get(i))) full.set(i, canonical.get(index++));
        StringBuilder value = new StringBuilder();
        for (String key : full) { if (value.length() > 0) value.append(';'); value.append(key); }
        SharedPreferencesUtil.putString(KEY, value.toString());
    }
    public static String label(String key) {
        if ("exit".equals(key)) return "退出";
        if ("login".equals(key)) return "登录";
        return MenuActivity.btnNames.get(key).first;
    }
    public static int icon(String key) {
        switch (key) {
            case "recommend": return R.drawable.icon_home;
            case "popular": return R.drawable.icon_menu_flame;
            case "search": return R.drawable.icon_search;
            case "dynamic": return R.drawable.icon_followings;
            case "message": return R.drawable.icon_reply;
            case "myspace": case "login": return R.drawable.icon_person;
            case "local": return R.drawable.icon_download;
            case "settings": return R.drawable.icon_setting;
            case "exit": return R.drawable.icon_logout;
            case "timeline": return R.drawable.icon_time;
            case "live": return R.drawable.icon_play_16;
            default: return R.drawable.icon_star;
        }
    }
}
