package com.RobinNotBad.BiliClient;

import android.app.Application;
import android.content.Context;
import android.view.View;
import android.widget.LinearLayout;

import com.RobinNotBad.BiliClient.activity.MenuActivity;
import com.RobinNotBad.BiliClient.theme.ThemeManager;
import com.RobinNotBad.BiliClient.theme.TopLightView;
import com.RobinNotBad.BiliClient.util.AccountStore;
import com.RobinNotBad.BiliClient.util.NextLayout;
import com.RobinNotBad.BiliClient.util.SharedPreferencesUtil;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.Robolectric;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.RuntimeEnvironment;
import org.robolectric.android.controller.ActivityController;
import org.robolectric.annotation.Config;

import static org.junit.Assert.*;

@RunWith(RobolectricTestRunner.class)
@Config(sdk = 28, application = NextFeaturesTest.TestApp.class)
public class NextFeaturesTest {
    public static class TestApp extends Application {
        @Override public void onCreate() {
            super.onCreate();
            BiliTerminal.context = this;
            SharedPreferencesUtil.sharedPreferences = getSharedPreferences("default", Context.MODE_PRIVATE);
            ThemeManager.init(this);
        }
    }

    @Before public void reset() {
        SharedPreferencesUtil.sharedPreferences.edit().clear()
                .putString("buvid3", "test-device")
                .putString("bili_ticket", "test-ticket").commit();
    }

    private void login(long id, String token) {
        SharedPreferencesUtil.sharedPreferences.edit()
                .putLong("mid", id)
                .putString("cookies", "DedeUserID=" + id + "; SESSDATA=session-" + id + "; bili_jct=csrf-" + id)
                .putString("csrf", "csrf-" + id)
                .putString("refresh_token", token).commit();
        AccountStore.saveCurrent();
    }

    @Test public void switchingRestoresCredentialsAndPreservesFirstAccount() {
        login(101, "refresh-one");
        login(202, "refresh-two");
        assertEquals(2, AccountStore.list().length());
        assertTrue(AccountStore.select(101));
        assertEquals(101, SharedPreferencesUtil.getLong("mid", 0));
        assertEquals("refresh-one", SharedPreferencesUtil.getString("refresh_token", ""));
        assertEquals("csrf-101", SharedPreferencesUtil.getString("csrf", ""));
        assertTrue(AccountStore.select(202));
        assertEquals("refresh-two", SharedPreferencesUtil.getString("refresh_token", ""));
    }

    @Test public void refreshAndDuplicateLoginUpdateExistingAccount() {
        login(101, "old");
        SharedPreferencesUtil.putString("refresh_token", "renewed");
        AccountStore.saveCurrent();
        assertEquals(1, AccountStore.list().length());
        assertEquals("renewed", AccountStore.list().optJSONObject(0).optString("refresh_token"));
    }

    @Test public void partialQrLoginCannotOverwritePreviousSession() {
        login(101, "first");
        SharedPreferencesUtil.putString("cookies", "DedeUserID=202; SESSDATA=second");
        AccountStore.saveCurrent();
        assertEquals("first", AccountStore.list().optJSONObject(0).optString("refresh_token"));
        assertTrue(AccountStore.list().optJSONObject(0).optString("cookies").contains("session-101"));
    }

    @Test public void storedAccountsSurvivePreferencesReopenAndUnknownSelection() {
        login(101, "first");
        SharedPreferencesUtil.sharedPreferences = RuntimeEnvironment.getApplication()
                .getSharedPreferences("default", Context.MODE_PRIVATE);
        assertEquals(1, AccountStore.list().length());
        assertFalse(AccountStore.select(999));
        assertEquals(101, SharedPreferencesUtil.getLong("mid", 0));
    }

    @Test public void removingOneAccountPreservesOtherAccount() {
        login(101, "first");
        login(202, "second");
        AccountStore.remove(101);
        assertEquals(1, AccountStore.list().length());
        assertEquals(202, AccountStore.list().optJSONObject(0).optLong("mid"));
    }

    @Test public void switchingResetsUnreadState() {
        login(101, "first");
        login(202, "second");
        SharedPreferencesUtil.putInt(SharedPreferencesUtil.MESSAGE_UPDATE_NUM, 17);
        SharedPreferencesUtil.putInt(SharedPreferencesUtil.DYNAMIC_UPDATE_NUM, 12);
        assertTrue(AccountStore.select(101));
        assertEquals(0, SharedPreferencesUtil.getInt(SharedPreferencesUtil.MESSAGE_UPDATE_NUM, -1));
        assertEquals(0, SharedPreferencesUtil.getInt(SharedPreferencesUtil.DYNAMIC_UPDATE_NUM, -1));
    }

    @Test public void menuUsesTwoCircularButtonsPerRowByDefault() {
        try (ActivityController<MenuActivity> controller = Robolectric.buildActivity(MenuActivity.class).setup()) {
            LinearLayout menu = controller.get().findViewById(R.id.menu_layout);
            assertEquals(2, ((LinearLayout) menu.getChildAt(0)).getChildCount());
            assertTrue(controller.get().findViewById(R.id.next_top_light) instanceof TopLightView);
            assertFalse(controller.get().findViewById(R.id.next_top_light).isClickable());
        }
    }

    @Test public void menuUsesThreeColumnsWhenSelected() {
        SharedPreferencesUtil.putInt(NextLayout.COLUMNS, 3);
        try (ActivityController<MenuActivity> controller = Robolectric.buildActivity(MenuActivity.class).setup()) {
            LinearLayout menu = controller.get().findViewById(R.id.menu_layout);
            assertEquals(3, ((LinearLayout) menu.getChildAt(0)).getChildCount());
        }
    }

    @Test public void backgroundDefaultsToPinkAndPersistsColorChoice() {
        assertEquals(ThemeManager.BILI_PINK, ThemeManager.getPersonalColor());
        ThemeManager.getInstance().setPersonalColor(0xFF66CCFF);
        assertEquals(0xFF66CCFF, ThemeManager.getPersonalColor());
        assertEquals(0xFF66CCFF, ThemeManager.palette().accent);
        assertEquals(0xFF000000, ThemeManager.palette().windowBackground);
    }

    @Test public void menuLayoutChangeDoesNotRecreateHomeOrChangeTheme() {
        int before = ThemeManager.getInstance().getGeneration();
        try (ActivityController<com.RobinNotBad.BiliClient.activity.settings.LayoutSettingsActivity> controller =
                Robolectric.buildActivity(com.RobinNotBad.BiliClient.activity.settings.LayoutSettingsActivity.class).setup()) {
            controller.get().findViewById(R.id.next_layout_triple).performClick();
            assertEquals(3, NextLayout.columns());
            assertEquals(before, ThemeManager.getInstance().getGeneration());
            assertTrue(controller.get().findViewById(R.id.next_layout_triple).isSelected());
        }
    }
    @Test public void colorPageHasFourRoundSwatchesPerRowAndOnlyAppliesOnSave() {
        int original = ThemeManager.getPersonalColor();
        try (ActivityController<com.RobinNotBad.BiliClient.activity.settings.BackgroundColorActivity> controller =
                Robolectric.buildActivity(com.RobinNotBad.BiliClient.activity.settings.BackgroundColorActivity.class).setup()) {
            LinearLayout content = controller.get().findViewById(R.id.nextSettingsContent);
            for (int i = 0; i < 3; i++) assertEquals(4, ((LinearLayout) content.getChildAt(i)).getChildCount());
            ((android.widget.FrameLayout)((LinearLayout)content.getChildAt(0)).getChildAt(1)).getChildAt(0).performClick();
            assertEquals(original, ThemeManager.getPersonalColor());
            android.widget.EditText hex = controller.get().findViewById(R.id.next_color_hex);
            assertEquals("#FF87B2", hex.getText().toString());
            hex.setText("#123456");
            controller.get().findViewById(R.id.next_color_save).performClick();
            assertEquals(0xFF123456, ThemeManager.getPersonalColor());
        }
    }
    @Test public void personalThemeHasExactlyTheThreeRequestedEntries() {
        try (ActivityController<com.RobinNotBad.BiliClient.activity.settings.ThemeSettingsActivity> controller =
                Robolectric.buildActivity(com.RobinNotBad.BiliClient.activity.settings.ThemeSettingsActivity.class).setup()) {
            LinearLayout content = controller.get().findViewById(R.id.nextSettingsContent);
            assertEquals(3, content.getChildCount());
            assertNotNull(controller.get().findViewById(R.id.next_personal_page));
            assertNotNull(controller.get().findViewById(R.id.next_personal_color));
            assertNotNull(controller.get().findViewById(R.id.next_personal_cards));
        }
    }
    @Test public void sortingPreservesHiddenItemsAndDoesNotChangeStartupOrder() {
        java.util.List<String> before = com.RobinNotBad.BiliClient.util.MenuOrder.visible();
        java.util.List<String> moved = new java.util.ArrayList<>(before);
        String last = moved.remove(moved.size()-1); moved.add(0, last);
        com.RobinNotBad.BiliClient.util.MenuOrder.saveVisible(moved);
        assertEquals(moved, com.RobinNotBad.BiliClient.util.MenuOrder.visible());
        assertEquals(13, com.RobinNotBad.BiliClient.util.MenuOrder.all().size());
        assertEquals("", SharedPreferencesUtil.getString(SharedPreferencesUtil.MENU_SORT, ""));
    }
    @Test public void dragEditorUsesCurrentColumnsAndSavesMovedCardsOnReturn() {
        SharedPreferencesUtil.putInt(NextLayout.COLUMNS, 3);
        java.util.List<String> before = com.RobinNotBad.BiliClient.util.MenuOrder.visible();
        ActivityController<com.RobinNotBad.BiliClient.activity.settings.CardSortActivity> controller =
                Robolectric.buildActivity(com.RobinNotBad.BiliClient.activity.settings.CardSortActivity.class).setup();
        androidx.recyclerview.widget.RecyclerView grid = controller.get().findViewById(R.id.next_card_preview);
        assertEquals(3, ((androidx.recyclerview.widget.GridLayoutManager)grid.getLayoutManager()).getSpanCount());
        assertTrue(controller.get().moveCard(0, 2, grid.getAdapter()));
        controller.pause().stop().destroy();
        assertEquals(before.get(0), com.RobinNotBad.BiliClient.util.MenuOrder.visible().get(2));
    }

    @Test
    @org.robolectric.annotation.GraphicsMode(org.robolectric.annotation.GraphicsMode.Mode.NATIVE)
    @Config(qualifiers = "w252dp-h333dp-hdpi")
    public void renderReferenceStyleForVisualReview() throws Exception {
        SharedPreferencesUtil.putLong("mid", 101);
        SharedPreferencesUtil.putInt(SharedPreferencesUtil.DYNAMIC_UPDATE_NUM, 99);
        ThemeManager.getInstance().setPersonalColor(ThemeManager.BILI_PINK);
        ThemeManager.getInstance().setDark(true);
        java.io.File folder = new java.io.File("build/reports/next"); folder.mkdirs();
        try (ActivityController<MenuActivity> controller = Robolectric.buildActivity(MenuActivity.class).setup().visible()) {
            android.view.View root = controller.get().getWindow().getDecorView();
            root.measure(View.MeasureSpec.makeMeasureSpec(378, View.MeasureSpec.EXACTLY), View.MeasureSpec.makeMeasureSpec(500, View.MeasureSpec.EXACTLY));
            root.layout(0, 0, 378, 500);
            ((android.widget.TextView)controller.get().findViewById(R.id.timeText)).setText("00:57");
            android.graphics.Bitmap bitmap = android.graphics.Bitmap.createBitmap(378, 500, android.graphics.Bitmap.Config.ARGB_8888);
            root.draw(new android.graphics.Canvas(bitmap));
            try (java.io.FileOutputStream output = new java.io.FileOutputStream(new java.io.File(folder, "menu-reference-preview.png"))) {
                assertTrue(bitmap.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, output));
            }
            bitmap.recycle();
        }
        try (ActivityController<com.RobinNotBad.BiliClient.activity.settings.ThemeSettingsActivity> controller =
                Robolectric.buildActivity(com.RobinNotBad.BiliClient.activity.settings.ThemeSettingsActivity.class).setup().visible()) {
            android.view.View root = controller.get().getWindow().getDecorView();
            root.measure(View.MeasureSpec.makeMeasureSpec(378, View.MeasureSpec.EXACTLY), View.MeasureSpec.makeMeasureSpec(500, View.MeasureSpec.EXACTLY));
            root.layout(0, 0, 378, 500);
            android.graphics.Bitmap bitmap = android.graphics.Bitmap.createBitmap(378, 500, android.graphics.Bitmap.Config.ARGB_8888);
            root.draw(new android.graphics.Canvas(bitmap));
            try (java.io.FileOutputStream output = new java.io.FileOutputStream(new java.io.File(folder, "theme-reference-preview.png"))) {
                assertTrue(bitmap.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, output));
            }
            bitmap.recycle();
        }
    }

    @Test public void referencePaletteUpgradeKeepsAccountsAndMenuAndAllowsLaterCustomColor() throws Exception {
        login(101, "first");
        SharedPreferencesUtil.putInt(NextLayout.COLUMNS, 3);
        java.util.List<String> order = com.RobinNotBad.BiliClient.util.MenuOrder.visible();
        SharedPreferencesUtil.putBoolean(SharedPreferencesUtil.THEME_DARK, false);
        SharedPreferencesUtil.putInt(ThemeManager.PERSONAL_COLOR, 0xFF66CCFF);
        java.lang.reflect.Method reload = ThemeManager.class.getDeclaredMethod("load"); reload.setAccessible(true);
        reload.invoke(ThemeManager.getInstance());
        assertTrue(ThemeManager.getInstance().isDark());
        assertEquals(ThemeManager.BILI_PINK, ThemeManager.getPersonalColor());
        assertEquals(1, AccountStore.list().length()); assertEquals(3, NextLayout.columns());
        assertEquals(order, com.RobinNotBad.BiliClient.util.MenuOrder.visible());
        ThemeManager.getInstance().setPersonalColor(0xFF66CCFF);
        reload.invoke(ThemeManager.getInstance());
        assertEquals(0xFF66CCFF, ThemeManager.getPersonalColor());
    }
}
