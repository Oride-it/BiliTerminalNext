# 云端构建与发布

应用名称：哔哩终端Next。安装包名：`com.iftts.bili`。
正式版本系列从 **1.2.1** 开始，版本配置以根目录 `version.properties` 为准。

## 构建环境

- 完整 JDK 17
- Android SDK 33
- Android Build Tools 35.0.0
- Gradle 使用仓库自带的 Wrapper

在项目根目录创建 `local.properties`：

```properties
sdk.dir=/path/to/android-sdk
KEY_PATH=/private/path/biliterminal-next.jks
KEY_PASSWORD=填写原发布密钥密码
ALIAS_NAME=biliterminal-next
ALIAS_PASSWORD=填写原发布密钥密码
```

正式发布私钥与密码单独保存，不进入源码仓库或 Release。
使用既有发布密钥才能覆盖更新此前安装包；不能随意重新生成密钥替换。

## 正式构建

```sh
./gradlew :app:testReleaseUnitTest :app:assembleRelease --no-daemon --max-workers=2
```

APK 输出位置：`app/build/outputs/apk/release/app-release.apk`。
R8 映射：`app/build/outputs/mapping/release/mapping.txt`。
测试报告：`app/build/reports/tests/testReleaseUnitTest/`。
构建开启代码混淆、优化和资源压缩。

## 后续版本

```sh
python3 scripts/bump_version.py --dry-run
python3 scripts/bump_version.py
```

例如 1.2.1 自动变为 1.2.2，同时增加 `VERSION_CODE`。
内部安装序号沿用先前较大的数值并继续递增，使版本名称改为 1.2.1 后仍可覆盖安装此前测试包。
提交前补充 `CHANGELOG.md`，构建并校验签名，然后使用与版本一致的 `v1.2.2` 标签创建 Release。

## 首次发布内容

- 标签与标题：`v1.2.1` / `哔哩终端Next 1.2.1`
- APK：`BiliTerminalNext-1.2.1-release.apk`
- SHA-256 校验文件与 R8 映射归档
- GitHub 自动提供标签对应的完整源码归档

界面支持圆外菜单文字、紧凑主题卡片、颜色预览保存和菜单拖动排序。
自动化检查包含账号与菜单持久化、颜色保存、排序和原生界面渲染；尚未使用真实账号完成实机登录和播放测试。
原生播放器架构沿用上游，不支持纯 64 位设备。

源码基于 PianoEthan/BiliTerminal，沿用 GPL-3.0 与原作者署名。
